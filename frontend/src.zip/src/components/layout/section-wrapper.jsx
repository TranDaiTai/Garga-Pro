// components/section-wrapper.tsx
export default function SectionWrapper ({ children, className = "" }) {
  return (
    <section className={`section-wrapper max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-15 ${className}`}>
      {children}
    </section>
  )
}
